﻿using AplicacionWPEF.dto;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace AplicacionWPEF.logica
{
    public class LogicaNegocio
    {
        //getters y setter bascios de la listaPeliculas
        public ObservableCollection<Pelicula> listaPeliculas { get; set; }

        //constructor de la listaPeliculas tenemos un constructor por defecto que añade una pelicula
        public LogicaNegocio()
        {
            listaPeliculas = new ObservableCollection<Pelicula>();
            listaPeliculas.Add(new Pelicula("Expediente Warren", "James Wan", "Terror", DateTime.Parse("19/07/2013")));
        }

        //añadimos una pelicula a la lista
        public void aniadirPelicula(Pelicula pelicula)
        {
            listaPeliculas.Add(pelicula);
        }

        //Sobrecargamos metodo en este caso el modificarPelicula
        //ademas accedemos a las posiciones de un array para poder moficar la pelicula que deseemos 
        public void modificarPelicula(Pelicula pelicula, int posicion)
        {
            listaPeliculas[posicion] = pelicula;
        }

        //Segundo metodo con el mismo nombre pero distintos parametros la utilizo para cambiar el titulo de la pelicula
        public void modificarPelicula(string tituloViejo, string tituloNuevo)
        { 
            foreach (Pelicula peli in listaPeliculas)
            {
                if (peli.Titulo.Equals(tituloViejo))
                {
                    peli.Titulo = tituloNuevo;
                }
            }
        }
    }
}
