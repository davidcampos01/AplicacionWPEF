﻿using AplicacionWPEF.dto;
using AplicacionWPEF.logica;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace AplicacionWPEF
{
    /// <summary>
    /// Lógica de interacción para DialogoPeliculas.xaml
    /// </summary>
    public partial class DialogoPeliculas : Window
    {
        private LogicaNegocio logicaNegocio;
        public Pelicula pelicula;
        private int posicion;
        private Boolean modificar;
        private int errores;
        public DialogoPeliculas(LogicaNegocio logicaNegocio)
        {
            InitializeComponent();
            this.logicaNegocio = logicaNegocio;
            pelicula = new Pelicula();
  
            this.DataContext = pelicula;
            modificar = false;
        }
        // Segundo constructor sobrecargado
        public DialogoPeliculas(LogicaNegocio logicaNegocio, Pelicula peliculaModificada, int pos)
        {
            InitializeComponent();
            this.logicaNegocio = logicaNegocio;
            this.pelicula = peliculaModificada;
            this.posicion = pos;
            this.DataContext = pelicula;
            modificar = true;
        }

        private void buttonCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void buttonAceptar_Click(object sender, RoutedEventArgs e)
        {
            if (modificar)
            {
                logicaNegocio.modificarPelicula(pelicula, posicion);
            }
            else
            {
                logicaNegocio.aniadirPelicula(pelicula);
            }

            // Una vez hayamos acabado cerramos la pantalla.
            this.Close();
        }
        //comprobamos si hay errores o cumple unas condiciones los campos y entonces habilitamos el boton de aceptar el cual por defecto esta deshabilitado
        //asociamos una funcion a la validacion de algun campo
        private void Validation_Error(object sender, ValidationErrorEventArgs e)
        {
            if (e.Action == ValidationErrorEventAction.Added)
                errores++;
            else
                errores--;
            if (errores == 0)
                botonAceptar.IsEnabled = true;
            else
                botonAceptar.IsEnabled = false;
        }
    }
}

