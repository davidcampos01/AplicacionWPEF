﻿using AplicacionWPEF.dto;
using AplicacionWPEF.logica;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;

namespace AplicacionWPEF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private LogicaNegocio logicaNegocio;
        public MainWindow()
        {
            InitializeComponent();
            logicaNegocio = new LogicaNegocio();
            // Establecemos un dataContext para un componente concreto
            // El DataContext de nuestra tabla llamada DataGridPeliculas es logicaNegocio
            DataGridPeliculas.DataContext = logicaNegocio;
        }

        private void NuevoMenuItem_Click(object sender, RoutedEventArgs e)
        {
            DialogoPeliculas dialogoLibro = new DialogoPeliculas(logicaNegocio);
            dialogoLibro.Show();
        }
        //Uso de eventos cuando demos click y cuando escribamos nos cambie el color de fondo
        private void buttonModificar_Click(object sender, RoutedEventArgs e)
        {

            if (DataGridPeliculas.SelectedIndex != -1)
            {

                Pelicula pelicula = (Pelicula)DataGridPeliculas.SelectedItem;

                DialogoPeliculas dialogoPeliculas = new DialogoPeliculas(logicaNegocio, (Pelicula)pelicula.Clone(), DataGridPeliculas.SelectedIndex);

                dialogoPeliculas.Show();
            }

        }

        private void BotonModificarTitulo_Click(object sender, RoutedEventArgs e)
        {
            string tituloNue = TituloNuevo.Text;
            string tituloVie = TituloViejo.Text;

            logicaNegocio.modificarPelicula(tituloVie, tituloNue);
        }

        private void TituloViejo_TextChanged(object sender, TextChangedEventArgs e)
        {
            TituloViejo.Background = Brushes.Red;//cambio el fondo del campo de texto
            TituloViejo.Foreground = Brushes.White;//cambio color de las letras
            LabelEtiqueta.Visibility = Visibility.Hidden;//oculto etiqueta
        }

        private void TituloNuevo_TextChanged(object sender, TextChangedEventArgs e)
        {
            TituloNuevo.Background = Brushes.Blue;//cambio el fondo del campo de texto
            TituloNuevo.Foreground = Brushes.White;//cambio color de las letras
        }
    }
}

