﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace AplicacionWPEF.dto
{
    public class Pelicula : INotifyPropertyChanged, ICloneable, IDataErrorInfo
    {
        //getter y setters basicos
        public String Nombre { get; set; }

        //getter y setters personalizados
        private String titulo;
        public String Titulo
        {
            get
            {
                return titulo;
            }
            set
            {
                titulo = value;
                this.PropertyChanged(this, new PropertyChangedEventArgs("Titulo"));
            }

        }
        private String director;
        public String Director
        {
            get
            {
                return director;
            }
            set
            {
                director = value;
                this.PropertyChanged(this, new PropertyChangedEventArgs("Director"));
            }
        }
        private String genero;
        public String Genero
        {
            get
            {
                return genero;
            }
            set
            {
                genero = value;
                this.PropertyChanged(this, new PropertyChangedEventArgs("Genero"));
            }
        }
        private DateTime fechaEntrada;
        public DateTime FechaEntrada
        {
            get
            {
                return fechaEntrada;
            }
            set
            {
                fechaEntrada = value;
                this.PropertyChanged(this, new PropertyChangedEventArgs("FechaEntrada"));
            }
        }

        //Creamos dos constructores para la misma clase 
        public Pelicula()
        {
            this.fechaEntrada = DateTime.Now;
        }
        public Pelicula(String titulo, String director, String genero, DateTime fechaEntrada)
        {
            this.titulo = titulo;
            this.director = director;
            this.genero = genero;
            this.fechaEntrada = fechaEntrada;
        }
        public event PropertyChangedEventHandler PropertyChanged;

        //sobreescrimos el metodo clone para poder trabajar sobre el con informacion de manera temporal
        public object Clone()
        {
            return this.MemberwiseClone();
        }
        public string Error
        {
            get { return ""; }
        }
        // si tenemos el campo de titulo, director o genero vacios nos muestra un mensaje de error con el texto que le hayamos indicado
        public string this[string columName]
        {
            get
            {
                string resultado = "";
                if (columName == "Titulo")
                {
                    if (string.IsNullOrEmpty(titulo))
                    {
                        resultado = "Debes introducir un Titulo para el Libro";
                    }

                }
                if (columName == "Director")
                {
                    if (string.IsNullOrEmpty(director))
                    {
                        resultado = "Debes introducir un Director para la pelicula";
                    }

                }
                if (columName == "Genero")
                {
                    if (string.IsNullOrEmpty(genero))
                    {
                        resultado = "Debes introducir un genero para la pelicula";
                    }

                }
                return resultado;

            }
        }
    }
}
